from django.urls import path
from . import views  # This imports views from the current directory (catalog/views.py)

urlpatterns = [
    path('', views.product_catalog, name='product_catalog'),
]