import csv
from django.core.management.base import BaseCommand
from catalog.models import Product

class Command(BaseCommand):
    help = "Import products from a CSV file"

    def handle(self, *args, **kwargs):
        file_path = '/Users/camillesilvio/Documents/MSYS30Final/ProductCatalog - Sheet1.csv'  # Update with the correct file path
        try:
            with open(file_path, 'r') as file:
                reader = csv.DictReader(file)
                for row in reader:
                    # Clean the price field by removing commas
                    price = row['Price'].replace(',', '')  # Remove commas from the price
                    # Convert the price to a decimal type
                    price = float(price)

                    # Create the product
                    Product.objects.create(
                        category=row['Category'],
                        name=row['Name'],
                        material=row['Material'],
                        price=price,  # Use the cleaned price value
                        image=row['Image']
                    )
            self.stdout.write(self.style.SUCCESS("Products imported successfully!"))
        except FileNotFoundError:
            self.stdout.write(self.style.ERROR(f"File not found: {file_path}"))
