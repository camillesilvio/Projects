from .models import Product
from django.shortcuts import render

def quicksort(products, key, reverse=False):
    
    if len(products) <= 1:
        return products
    
    # Choose the first product as the pivot element
    pivot = products[0]
    
    # Initialize two empty lists to hold products smaller and larger than the pivot
    less = []
    greater = []
    
    
    for item in products[1:]:
        if (getattr(item, key) <= getattr(pivot, key)) != reverse:
            # If the item should go to the 'less' list, append it
            less.append(item)
        else:
            # Otherwise, append it to the 'greater' list
            greater.append(item)
    
   
    return quicksort(less, key, reverse) + [pivot] + quicksort(greater, key, reverse)


# Linear search for partial matching in product names
def search_products(products, search_term):
    # Convert to lowercase for case sensitive
    search_terms = search_term.lower().split()  # Split the search term into words

    # Initialize an empty list to hold the matching products
    matched_products = []

    # Loop over each product in the products list
    for product in products:
        product_name = product.name.lower()

        # Flag to check if the product matches all search terms
        matches_all_terms = True

        
        for term in search_terms:
            if term not in product_name:
                matches_all_terms = False
                break  # No need to check further terms if one is not matched

        # If all terms matched, add the product to the matched_products list
        if matches_all_terms:
            matched_products.append(product)

    return matched_products

def product_catalog(request):
    # Get the distinct categories
    categories = Product.objects.values_list('category', flat=True).distinct()

    # Get all products
    products = list(Product.objects.all())  

   
    if 'search' in request.GET and request.GET['search']:
        search_term = request.GET['search']
        products = search_products(products, search_term)

    # Apply category filter
    if 'category' in request.GET and request.GET['category']:
        products = [product for product in products if product.category == request.GET['category']]

    # Apply price sorting using quicksort
    if 'price' in request.GET and request.GET['price']:
        if request.GET['price'] == 'asc':
            products = quicksort(products, key='price')
        elif request.GET['price'] == 'desc':
            products = quicksort(products, key='price', reverse=True)

    return render(request, 'catalog/product_catalog.html', {'products': products, 'categories': categories})

